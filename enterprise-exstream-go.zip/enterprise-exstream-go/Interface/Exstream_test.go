package Exstream

import (
  "errors"
  "testing"
  "github.com/stretchr/testify/require"
  )

type fakeSession struct{
  result string
  err error
}

func (f fakeSession) getSessionId() (string ,error) {
  if f.err != nil {
    return "", f.err
  }
  return f.result, nil
}

func TestGetSessionId(t *testing.T) {
  f := fakeSession{
    result : "12345678",
    err : nil,
  }
  msg ,err := GenerateSession()

  expectedresult := f.result
  require.Equal(t, msg , expectedresult)
  require.Equal(t , err , nil)
}

func TestErrorGetSessionId(t *testing.T) {
  f := fakeSession{
    result : "",
    err : errors.New("test error"),
  }
  expectedresult := f.err

  msg ,err := GenerateSession()

  require.Equal(t , err , expectedresult)
  require.Equal(t, msg , "")
}
