package Exstream

import (
  "Application"
)

///create interface for Exstream with methods
type ExstreamServices interface{
  getSessionId() (string, error)
}

type Session struct{
  SessionId string
  err error
}

///Function to actually query the Exstream API for information.
func getSessionId() (string , error)  {
  r , err := ExstreamService.FetchSession()
  if err != nil {
    return "", err
  }
	return r, nil
}

///Function to get the data from Exstream
func GenerateSession() (string , error)  {
  r,err := getSessionId()
  if err != nil {
    return "" , err
  }
  return r, nil
}

//func main()  {
  //msg ,err := GenerateSession()
  //if err != nil {
    //fmt.Errorf("Error getting SessionId %s", err)
  //}
  //fmt.Println(msg +" ----success-------")
//}
