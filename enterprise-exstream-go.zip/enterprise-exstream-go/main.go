package main

import (
    "fmt"
    "html"
    "log"
    "net/http"
    "encoding/json"
    "Interface"

    "github.com/gorilla/mux"
)

type Session struct {
    Key string `json:"key"`
}

type Sessions []Session

func main() {
  router := mux.NewRouter().StrictSlash(true)
  router.HandleFunc("/", Index)
  router.HandleFunc("/Authentication" , Authentication)

  log.Fatal(http.ListenAndServe(":8080", router))
}

func Index(w http.ResponseWriter, r *http.Request) {
    fmt.Fprintf(w, "jiwan test, %q", html.EscapeString(r.URL.Path))
}

func Authentication(w http.ResponseWriter, r *http.Request)  {
  msg , err := Exstream.GenerateSession()
  if err != nil{
    panic(err)
  }

  sessionIds := Sessions{
        Session{Key: msg },
    }

    if err := json.NewEncoder(w).Encode(sessionIds); err != nil {
        panic(err)
    }
}
